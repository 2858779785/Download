# -*- coding: utf-8 -*-
# @Time : 2021/11/2 16:41
# @Author : Melon
# @Site : 
# @Note : 
# @File : StartWork.py
# @Software: PyCharm

import MoocMain.initMooc as mooc_init
import requests
import time

# ****************************************** 配置 ******************************************
# 账号1(大号)
username1 = ""  # 账号
password1 = ""  # 密码
# 账号2(小号)
username2 = "2676422375"  # 账号
password2 = "WOAIni520"  # 密码

# 账号1(大号)刷课
is_look_video = True

# 小号退出所有课程
is_withdraw_course = True

# 做作业
is_work_exam_type0 = True

# 做测验
is_work_exam_type1 = True

# 考试
is_work_exam_type2 = True

# 大于90分的不进行再次作答
is_work_score = 99

# 需要跳过的课程，填写方式例： ['大学语文', '高等数学']
is_continue_work = []

# ****************************************** 结束 ******************************************

#程序版本验证
def Check():
    version = requests.get('https://xinyucode.gitee.io/download/zjy_mooc_startwork.html')
    version = str(version.text)
    if version == '1.0.0':
        print("程序验证成功！继续执行 开发者QQ:2858779795 WX:tjtj0125")
        print("版本号："+version)
        Statement()
    else:
        print("程序验证失败！请联系开发者获取最新程序，程序即将退出！开发者QQ:2858779795 WX:tjtj0125")
        time.sleep(5)
        exit()

#免责声明
def Statement():
    sytk = '''----------------使---用---条---款-------------------
本软件完全开源，仅供学习研究使用，请勿非法使用及商用，
出现一切责任，与开发者无关，请下载于12小时之内删除!
----------------------------------------------------'''
    syjc = '''----------------使---用---教---程-------------------
1.大号是需要跑进度的账号
2.小号是随便一个职教云账号（建议随便注册一个不用的账号）
注：小号去职教云官方随便注册一个即可,用来采集答案
----------------------------------------------------'''
    print(sytk)
    userinput=input('是否同意相关条款(y/N):')
    if userinput == 'y':
        print("您已同意相关条款，程序开始执行")
        time.sleep(2)
        print(syjc)
        Start()
    else:
        print("您已拒绝同意相关条款，程序即将退出！")
        time.sleep(5)
        exit()

#程序开始
def Start():
    return mooc_init.run(
        #username1=input('请输入大号登录账号：'),
        #password1=input('请输入大号登录密码：'),
        username1=username1,
        password1=password1,
        username2=username2,
        password2=password2,
        #username2=input('请输入小号登录账号：'),
        #password2=input('请输入小号登录密码：'),
        is_look_video=is_look_video,
        is_withdraw_course=is_withdraw_course,
        is_work_exam_type0=is_work_exam_type0,
        is_work_exam_type1=is_work_exam_type1,
        is_work_exam_type2=is_work_exam_type2,
        is_work_score=is_work_score,
        is_continue_work=is_continue_work,
    )

if __name__ == '__main__':
    Check()